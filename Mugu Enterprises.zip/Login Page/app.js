// Smooth Scrolling for Navigation Links
document.querySelectorAll(".navbar a").forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const targetId = e.target.getAttribute("href").substring(1);
    const targetSection = document.getElementById(targetId);
    if (targetSection) {
      targetSection.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  });
});

document
  .getElementById("contact-form")
  .addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent default form submission

    const statusMessage = document.getElementById("status");
    statusMessage.textContent = "Sending...";

    // Collect form data
    const formData = {
      name: document.getElementById("name").value,
      email: document.getElementById("email").value,
      message: document.getElementById("message").value,
    };

    // Send email using EmailJS
    emailjs
      .send("service_ehkwymp", "template_sqei764", formData) // Replace with your IDs
      .then(
        function () {
          statusMessage.textContent = "Message sent successfully!";
          document.getElementById("contact-form").reset();
        },
        function (error) {
          statusMessage.textContent =
            "Failed to send message. Please try again.";
          console.error("EmailJS Error: ", error);
        }
      );
  });

// JavaScript to toggle navbar links on smaller screens
const burger = document.querySelector(".burger");
const nav = document.querySelector(".nav-links");

burger.addEventListener("click", () => {
  nav.classList.toggle("active");
  burger.classList.toggle("toggle");
});
